/**
 */
(async function () {
 setGameMetrics(2560, 1440, 1);


    // 启用自动拾取的实时任务
    dispatcher.addTimer(new RealtimeTimer("AutoPick", { "forceInteraction": true }));
	log.info('前往枫丹挖矿，共有100+矿点耗时约30分钟，队伍中必需携带{zl}在1号位，推荐e技能回血角色在二号位', '钟离');

	//切换2号位给1号位回血
	async function HPrestoral() {
      keyPress("2");
	  await sleep(1000);
      keyPress("e");
	  await sleep(1500);
      keyPress("1");
	  await sleep(3500);
    }
	
	
	//
	async function minePlay(locationName,num,takeTime) {
        log.info('前往 {name}', locationName);
		await HPrestoral();
        log.info('矿点约{num}个,耗时约{takeTime}分钟', num,takeTime);
        let filePath = `assets/${locationName}.json`;
		
	const startTime = Date.now();
	await pathingScript.runFile(filePath);
	// 计算并输出总时长
    const endTime = Date.now();
    const totalTimeInSeconds = (endTime - startTime) / 1000;
    // 将总时长转换为分钟和秒的形式
    const minutes = Math.floor(totalTimeInSeconds / 60);
    const seconds = totalTimeInSeconds % 60;
    // 格式化输出
    const formattedTime = `${minutes}分${seconds.toFixed(0).padStart(2, '0')}秒`;
    log.info(`${locationName}运行总时长：${formattedTime}`);   
    }
	
	
	
	/**
	*/
	
	await minePlay('枫丹厅西北',4,1);
	await minePlay('枫丹厅西北2',20,4.5);
	await minePlay('枫丹厅西北下',6,1.5);
	
	await minePlay('新枫丹科学院西北',3,1);
	await minePlay('新枫丹科学院东南',3,1);
	await minePlay('新枫丹科学院东北',10,3.5);
	
	await minePlay('中央实验室基地东',5,2);
	await minePlay('中央实验室基地东南',5,1);
	await minePlay('中央实验室基地东北',3,1);
	await minePlay('优兰尼娅湖北',9,2.5);
	await minePlay('幽林雾道北',6,2);
	await minePlay('卡布狄斯堡1',9,2.5);
	await minePlay('秋分山西侧北',6,2);
	
	await minePlay('猎人本南',4,1);
	await minePlay('仓晶区南',4,1.5);
	await minePlay('仓晶区南2',4,1);
	await minePlay('仓晶区南3',4,1);
	
	/*
	
	
	
	*/
	
	
	
})();